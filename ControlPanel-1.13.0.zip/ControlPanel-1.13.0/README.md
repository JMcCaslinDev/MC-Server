# ControlPanel Addon
[![Discord](https://img.shields.io/discord/272499714048524288.svg?logo=discord)](https://discord.bentobox.world)
[![Build Status](https://ci.codemc.org/buildStatus/icon?job=BentoBoxWorld/ControlPanel)](https://ci.codemc.org/job/BentoBoxWorld/job/ControlPanel/)

This is simple ControlPanel for all BentoBox GameMode addons. Allows to customize GUI for users.

## How to use

1. Place the addon jar in the addons folder of the BentoBox plugin
2. Restart the server
3. Use admin command to import control panels.

## Compatibility

- [x] BentoBox - 1.7.0 version
- [x] BSkyBlock
- [x] AcidIsland
- [x] SkyGrid
- [x] CaveBlock

## Information

More information can be found in [Wiki Pages](https://github.com/BentoBoxWorld/ControlPanel/wiki).
